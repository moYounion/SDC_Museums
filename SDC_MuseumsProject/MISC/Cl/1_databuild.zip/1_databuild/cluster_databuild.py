#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 15 09:46:25 2019

@author: terry
"""

import pandas as pd


data = pd.read_csv('Final_Data.csv',delimiter = ',')
classesHot =pd.read_csv('encoded_classes.csv',delimiter = ',')
MediumHot =pd.read_csv('encoded_list.csv',delimiter = ',')
UniqueHot =pd.read_csv('encoded_unique.csv',delimiter = ',')
Geocodes = pd.read_csv('geocodes.csv',delimiter = ',')

classesHot=classesHot.drop("Unnamed: 0",axis=1)
MediumHot =MediumHot.drop("Unnamed: 0",axis=1)
UniqueHot =UniqueHot.drop("Unnamed: 0",axis=1)

classesHot.dtypes
MediumHot.dtypes

UniqueHot.iloc[:,0]=MediumHot.iloc[:,0]

UniqueHot.dtypes

classesHot.isnull().sum().sum()
MediumHot.isnull().sum().sum()
UniqueHot.isnull().sum().sum()
classesHot.isna().sum().sum()
MediumHot.isna().sum().sum()
UniqueHot.isna().sum().sum()

ClusterData_Base = data[["Object ID","object_begin_date"]]
ClusterData_Base.columns=["Object ID","age"]
ClusterData_Base=ClusterData_Base.merge(Geocodes,how="left",left_on="Object ID",right_on="Object ID")
ClusterData_Base=ClusterData_Base.merge(classesHot,how="left",left_on="Object ID",right_on="Object ID")

ClusterData1=ClusterData_Base.merge(MediumHot,how="left",left_on="Object ID",right_on="Object ID")
ClusterData2=ClusterData_Base.merge(UniqueHot,how="left",left_on="Object ID",right_on="Object ID")

cols_to_order =["Object ID","age","country","class","medium","coordX","coordY"]
new_columns = cols_to_order + list(ClusterData1.columns.drop(cols_to_order))

ClusterData1=ClusterData1[new_columns]
ClusterData2=ClusterData2[new_columns]

ClusterData1.isnull().sum().sum()
ClusterData2.isnull().sum().sum()
ClusterData1.isna().sum().sum()
ClusterData2.isna().sum().sum()

ClusterData1.to_csv("ClusterData1.csv")
ClusterData2.to_csv("ClusterData2.csv")
